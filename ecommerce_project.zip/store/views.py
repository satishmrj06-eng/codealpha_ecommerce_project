from django.shortcuts import render, redirect, get_object_or_404
from .models import Product, Order

cart = []

def product_list(request):
    products = Product.objects.all()
    return render(request, 'product_list.html', {'products': products})

def product_detail(request, id):
    product = get_object_or_404(Product, id=id)
    return render(request, 'product_detail.html', {'product': product})

def add_to_cart(request, id):
    product = get_object_or_404(Product, id=id)
    cart.append(product)
    return redirect('cart')

def cart_view(request):
    total = sum(p.price for p in cart)
    return render(request, 'cart.html', {'cart': cart, 'total': total})

def checkout(request):
    cart.clear()
    return render(request, 'checkout.html')
